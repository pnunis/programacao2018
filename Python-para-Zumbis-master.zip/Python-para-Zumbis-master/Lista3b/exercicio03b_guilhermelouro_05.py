#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Faça um programa que peça um inteiro positivo e o mostre invertido. Ex.: 1234 gera 4321 
"""
print str(input('Entre com o número: '))[::-1]