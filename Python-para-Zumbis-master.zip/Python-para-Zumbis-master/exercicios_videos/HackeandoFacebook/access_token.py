#!usr/bin/env python 
# -*- coding: utf-8 -*-

token = 'CAACEdEose0cBAJErn38PZCsULwtMGhrcXwlKZCyp19tZCaaMqrT0UGi9qKj8JdHBeYv97pGYCJICbG2BwLcGZCNwnZAZB0pbMZCORVXM8P0yRsZCNj2vj0aDxxaA8EHa2UbEokJsm9VPqwgHeycbk2CAGJtGlsUL7f0ZAiRBiuWqF5VUMbsduCkJsLD7fTEMUvywZD'