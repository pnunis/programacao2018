#!usr/bi/env python
#-*- coding:utf-8 -*-
count = 0
for i in range(1,10):
	if not i == 3:
		for j in range(1, 7):
			print "oi"
			count += 1
print count