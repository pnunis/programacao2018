#!usr/bi/env python
#-*- coding:utf-8 -*-

x = 2
y = 5
if y > 8:
	y *= 2
else:
	x *= 2
print(x + y)