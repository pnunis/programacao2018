#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Sabendo que str( ) converte valores numéricos para string, calcule quantos dígitos há em 2 elevado 
a um milhão.
"""

print ('2 elevado a 1 milhão tem %d digitos' %len(str(2**1000000)) )