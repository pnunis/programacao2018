#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Converta uma temperatura digitada em Fahrenheit para Celsius. 

f = input("Digite a temperatua em Fahrenheit: ")
c = (f - 32) / 1.8

print ('%d graus Celsius' %c)