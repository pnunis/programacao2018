#!/usr/bin/env python
# -*- coding: utf-8 -*-
# 2) Escreva um programa que leia um valor em metros e o exiba convertido em milímetros

metros = input("Entre com um número: ")
print metros,"metros equivale a", metros*1000, "milímetros"