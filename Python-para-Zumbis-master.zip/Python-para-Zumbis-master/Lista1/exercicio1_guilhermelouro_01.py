n1 = int(input("Entre com o primeiro numero: "))
n2 = int(input("Entre com o segundo numero: "))

print n1," + ",n2,"=",n1+n2