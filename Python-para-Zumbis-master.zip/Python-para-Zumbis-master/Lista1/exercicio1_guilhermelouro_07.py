#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Converta uma temperatura digitada em Celsius para Fahrenheit. F = 9*C/5 + 32 

c = input("Digite a temperatua em Celsius: ")
f = 9*c/5 + 32

print ('%d Fahrenheit' %f)